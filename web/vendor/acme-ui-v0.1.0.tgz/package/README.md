# UI library template for coding agents

A headless React 19 UI library template in which an agent builds a component from spec to review with one
command. Inside: a reference core (core, button, overlay, list, virtual and a Select component), live tests
in Chromium, and size and render budgets as gates. Around it, the layer for agents: `AGENTS.md`,
`CLAUDE.md`, path rules for Claude Code, Cursor and Copilot, subagents, skills, commands and hooks; a
step runner that drives Claude Code, Codex, Gemini CLI, Cursor, Copilot or any other agent CLI with any
model; batches of up to twenty components at once; and design input from pictures and Figma.

Every agent-facing file is plain English Markdown, so Claude Code, Cursor, Codex, Copilot and other agents
read the same instructions. Why each rule exists, with the measurements behind it: `docs/decisions/`.

## Start

```bash
git clone <this repository> my-ui && cd my-ui
npm install
npx playwright install chromium        # or set CHROMIUM_PATH=/path/to/chromium
node scripts/init.mjs --name @me/ui --prefix me
npm run gates                          # everything must be green before the first change
git add -A && git commit -m "chore: init from template"
```

`init.mjs` replaces the package name `@acme/ui` and the prefix `acme` everywhere, once: `acme-*` classes,
`--acme-*` variables, `acme.*` layers, rules and docs. Then it regenerates the Cursor rules.

## A component in one command

In Claude Code:

```
/new-component Switch an on/off switch for a settings page, with a visible label
```

A component is built in ten steps. Each step has a budget in tool calls, a unit of work that ends in a
commit, and a mechanical exit check. The steps are defined once in `scripts/lib/workflow-steps.mjs`; their
instructions live in `.claude/skills/component-step/steps/`.

| Step | Who does it | Exit (checked by `scripts/workflow.mjs done`) |
| --- | --- | --- |
| spec | `component-architect` | spec from the template, with the design references; open questions marked `[CRITICAL]` or `[NEEDS CLARIFICATION]` |
| test-plan | `test-writer`, plan mode | test table; every acceptance line `AC<n>` traced to a row |
| approve | a person (unattended runs stop on `[CRITICAL]` questions and record their other assumptions) | `Status: approved`, no open questions |
| tests | `npm run new` scaffold, then `test-writer` | one test per plan row; tests fail on assertions |
| implement | `implementer` | all green, tests unchanged |
| budgets | Claude | budgets measured, `npm run gates` green |
| review | three reviewers in parallel, four with design references | findings in `.workflow/<name>.review.md` |
| fix | `implementer` | no open findings |
| verify | mutation probe, three runs, `spec-reviewer` | every surviving mutant killed or explained, verdict done |
| finish | Claude | one commit with the evidence in its message |

Work happens on the `feat/<name>` branch. Every unit of work is a WIP commit, so a run that is cut off
loses at most one unit: out of turns, out of budget, a rate limit, a closed laptop. At the end the WIP
commits are squashed into one. Details and numbers: `docs/decisions/0009-token-iterable-workflow.md`.

What holds the budget:
- the `step-budget` hook counts tool calls on the current step, subagents included. At 80% of the budget
  it asks the agent to finish the unit of work, commit and write a note; at 100% it asks it to stop;
- subagents have `maxTurns`;
- `claude -p` runs add hard `--max-turns` and `--max-budget-usd` limits on top;
- the `Stop`, `SubagentStop`, `PreCompact` and `SessionEnd` hooks commit whatever is left in the tree;
- what only a person can settle (a wrong test or spec, missing access) the agent marks with
  `workflow.mjs block`. Later runs of the step stop at `begin`, the runner exits with code 3 and does not
  spend its remaining attempts. A person clears it with `reopen` or `unblock`.

To continue after a stop in a session: `/resume-component`. After a context compaction the `SessionStart`
hook brings the step status back.

Unattended, one agent process per step (`claude -p` unless a profile says otherwise):

```bash
node scripts/run-component.mjs Switch --request "an on/off switch for a settings page, with a visible label"
node scripts/run-component.mjs Switch --until approve   # stop to read the spec first
node scripts/run-component.mjs Switch --scale 0.5       # half the budgets
node scripts/run-component.mjs Switch --profile codex   # another agent or model (agents.config.json)
```

A person starts the runner from a terminal; `.claude/settings.json` denies it to agents, so the process
cannot spawn itself. The runner can be started again at any time: it continues from the first unfinished
step in the progress file. After every run it commits what is there, records turns, tool calls and cost,
and runs the step's exit check itself. If a step does not finish within `--runs` attempts, the runner
stops and says which note to read. In this mode the approve step accepts the spec with its assumptions,
and they end up in the final commit.

Before the first unattended run in a fresh clone, open `claude` in the folder once and accept the trust
prompt. In an untrusted folder Claude Code ignores `permissions.allow` (`Ignoring 12 permissions.allow
entries`), and `npm` and `node` commands in `-p` are refused. The runner passes `--permission-mode
acceptEdits`: since Claude Code 2.1.302, `-p` otherwise starts in manual mode and nobody can approve file
edits.

Other commands: `/component-step <Name> <step>`, `/add-part Select Group`, `/perf-check`,
`/release-check`, `/adr`, `/review-change`, `/gates`, `/catchup`. `/review` is taken by Claude Code's
built-in code review, hence `/review-change`.

## Many components at once

```bash
node scripts/run-batch.mjs wave-1.json --parallel 20 --max-usd 100 --until approve   # specs first
node scripts/run-batch.mjs wave-1.json --merge                                       # the rest, then merge
node scripts/run-batch.mjs wave-1.json --status
node scripts/run-batch.mjs wave-1.json --base theme/dark --merge                     # into a branch, not main
```

```json
{ "id": "wave-1",
  "defaults": { "profile": "claude-sonnet" },
  "components": [
    { "name": "Switch", "request": "an on/off switch for a settings page", "refs": ["design/switch.png"] },
    { "name": "Tabs", "request": "tabs for a settings page", "figma": "https://www.figma.com/design/<key>/UI?node-id=12-34" },
    { "name": "Slider", "request": "a range slider", "profile": "codex" } ] }
```

- Each component gets a git worktree in `../<repo>-worktrees/<name>` and its own step runner; the batch
  prints a table every minute and lists the components that wait for a person.
- One test service per machine (`node scripts/test-service.mjs start --memory 4096`, started by the
  batch if it is not running) holds one Chromium and a fixed number of test slots: ten test pages took
  1,736 MB in one browser against 6,676 MB in ten. The agents need memory too: one Claude Code runner
  peaked at 543 MB in a live batch, so twenty need about 11 GB besides the tests; the batch warns when
  `--parallel` does not fit the machine.
- `--max-usd` caps the whole batch: every run's cost goes to a ledger, no run starts once the cap is
  spent (exit 4), and each run may spend at most what was left when it started. Runs in parallel can
  together pass the cap by up to what each could spend (with Claude Code at most one step's dollar
  limit each). Agents that report no cost need prices in `agents.config.json`, or `--allow-unpriced`.
- The merge queue lands finished components one at a time: rebase onto main, `npm run gates`,
  fast-forward. `budgets.json`, `package.json` and the shared test files merge without a person
  (`.gitattributes`); a real conflict or a red gate stays on its branch.
- Questions: only `[CRITICAL]` ones (a public name, the pattern, a dependency, a conflict with the
  design, scope) stop a component for a person; the rest are settled and written down.
- Several machines: each runs `--worker --remote origin` (a component is claimed through a ref on the
  remote when a lane is free for it, so no two machines take the same one and a machine that starts
  later still finds work) and one runs `--merge-only --remote origin`, which follows the branches the
  workers pushed, the squashed ones included. The cap is per machine.

Worktrees inherit the folder trust of the checkout, so the trust prompt is needed once. Why it is
built this way, with the numbers: `docs/decisions/0011-parallel-batches.md`.

## Any agent, any model

`agents.config.json` holds profiles: an agent, a model, environment and arguments. The runner takes
`--profile`, else the profile the config names for the step, else `"default"`:

```json
{ "default": "claude",
  "steps": { "spec": "claude-opus", "implement": "codex", "review": "claude-sonnet" },
  "profiles": {
    "claude-opus": { "agent": "claude", "model": "claude-opus-5-5" },
    "codex": { "agent": "codex", "model": "<model>" },
    "kiro": { "agent": "generic", "command": ["kiro-cli", "chat", "--no-interactive", "--trust-all-tools", "{prompt}"] } },
  "prices": { "<model>": { "input": 1.25, "cachedInput": 0.125, "output": 10 } } }
```

| Agent | Step budget | Push and publish denied by | Key |
| --- | --- | --- | --- |
| Claude Code | its hook (warns at 80%), `--max-turns`, `--max-budget-usd` | `.claude/settings.json` | `ANTHROPIC_API_KEY` or login |
| Codex | the runner counts tool calls and stops it | `.codex/rules/default.rules`; its sandbox has no network | `CODEX_API_KEY` or `codex login` |
| Gemini CLI | the runner, and `maxSessionTurns` | a policy in a per-run Gemini home | `GEMINI_API_KEY` |
| Cursor | the runner | `.cursor/cli.json` | `CURSOR_API_KEY` |
| Copilot | the runner | `--deny-tool` | `COPILOT_GITHUB_TOKEN` |
| any CLI (`generic`) | the runner, from the events you map; else time only | its own config (Kiro: `.kiro/agents/ui-runner.json`) | `keyVariable` |

The deny lists match the start of a command: they keep an agent from pushing or spending by mistake,
not one set on working around them. `npm run check` fails if any of them stops denying push, publish
or the runners, and the runner stops a run that changed `.git/config` or `.git/hooks` (they run outside
every sandbox).

- Any model: a profile's `env` points the agent elsewhere: an LLM gateway for Claude Code
  (`ANTHROPIC_BASE_URL`), a provider in `~/.codex/config.toml` for Codex (`"provider"`), local models
  through Codex `--oss`, `COPILOT_PROVIDER_*` for Copilot. `"$NAME"` values come from the environment
  or the keys file.
- Many keys: `ANTHROPIC_API_KEY_POOL=key1,key2` (any variable plus `_POOL`) in the keys file. Each run
  takes the least used key; a rate limit cools that key and does not count as an attempt. Providers
  limit per organization or project, so keys add capacity only from different ones.
- A new CLI: add a `generic` profile, run `node scripts/agent-smoke.mjs <profile> --capture`, read the
  event types it lists, and map the tool-call event under `"events"`.
- Check every installed CLI with your logins: `node scripts/agent-smoke.mjs`. Per agent it writes a
  file, commits, tries a push that must be refused, and runs a task that must be stopped at a budget of
  three calls (not for Claude Code, whose hook stops it). Two short runs per agent at most.

Keys, and how tokens and money are counted: the next section. Why, and what was verified:
`docs/decisions/0012-agent-adapters.md`.

## Keys and tokens

Check everything with one command before a batch: `node scripts/agent-keys.mjs`. It lists every key a
profile needs, where it comes from and its fingerprint (never the value), how each profile's runs are
counted against `--max-usd`, the models that still need a price, and token-shaped strings in tracked
files.

### Where each key goes

On your machine every key goes in one file outside every repository: `~/.config/ui-agents/env`
(`cp agents.env.example ~/.config/ui-agents/env`, then fill it in; `UI_AGENTS_ENV` names another file).
On GitHub the cloud agent needs no agent keys, because GitHub bills the session; only Figma's token goes
there.

| Variable | For | Where to get it | On your machine | On GitHub |
| --- | --- | --- | --- | --- |
| `ANTHROPIC_API_KEY` | Claude Code profiles | console.anthropic.com, API keys; or leave it out and use the `claude` login | keys file | - |
| `ANTHROPIC_AUTH_TOKEN`, `LLM_GATEWAY_URL` | `claude-gateway` | your LLM gateway | keys file | - |
| `CODEX_API_KEY` | `codex` | platform.openai.com, a project key; or `codex login` | keys file | - |
| `GEMINI_API_KEY` | `gemini` | aistudio.google.com, a key on a paid project | keys file | - |
| `CURSOR_API_KEY` | `cursor` | cursor.com/dashboard, API keys; or `agent login` | keys file | - |
| `COPILOT_GITHUB_TOKEN` | `copilot` | a fine-grained personal access token with the "Copilot Requests" permission; or `copilot` /login | keys file | - |
| `KIRO_API_KEY` | `kiro` | Kiro Pro and up | keys file | - |
| `FIGMA_TOKEN` | `--figma`, `figma-ref.mjs` | Figma, Settings, Security, Personal access tokens: scope `file_content:read`, at most 90 days | keys file | Settings > Secrets and variables > Agents |
| any `"$NAME"` in a profile's `env` | that profile | - | keys file | - |

Rules the runners apply, so a key is used where it should be and nowhere else:
- A variable set in the shell wins over the keys file. A Claude Code profile with `ANTHROPIC_API_KEY`
  set bills the API account, not your subscription: leave it out to use the login.
- `<VARIABLE>_POOL=key1,key2` instead of `<VARIABLE>`: each run takes the least used key; a rate limit
  cools that key (60 s, doubling up to 15 min) and does not count as an attempt; a spend limit or an
  empty balance is an error, not a rate limit. Providers limit per organization (Anthropic) or project
  (OpenAI), so a pool adds capacity only with keys from different ones.
- A run gets its own agent's key and the variables its profile names. Every other provider's key, every
  pool and `FIGMA_TOKEN` are removed from its environment, even when the shell exports them.
- Key leases, the batch ledgers and the claims live in `~/.local/state/ui-agents/<repository id>/`, which
  no agent writes; leases store fingerprints only.
- `npm run check` fails on a tracked `.env` file or a token-shaped string (Anthropic, OpenAI, Google,
  GitHub, Figma) in any tracked file.

### How tokens and money are counted

Every run's tokens go to the batch ledger per model (input without the cached part, cached input,
output), with its cost:

| Agent | Tokens | Dollars |
| --- | --- | --- |
| Claude Code | per model, subagents included (`modelUsage`); cache writes counted as input | reported by Claude Code, used as is |
| Codex | per run (`turn.completed`), under the profile's `"model"` | tokens x `"prices"` of that model |
| Gemini CLI | per model it reports (its router can use two) | tokens x `"prices"` of each model |
| Copilot | per call and model (`assistant.usage`) | tokens x `"prices"` of each model |
| Cursor | none | not counted: needs `--allow-unpriced` |
| generic | what `"events.usage"` maps, under `"events.model"` or the profile's `"model"` | `"events.cost"`, else tokens x `"prices"` |

```json
"prices": { "<model as the agent reports it>": { "input": 1.25, "cachedInput": 0.125, "output": 10 } }
```

Dollars per million tokens, keyed by the model name the agent reports: run `agent-smoke.mjs` once and
`agent-keys.mjs` lists the names it saw. A batch refuses to start a profile it cannot count at all
(Cursor, a generic CLI without usage, Codex without a priced `"model"`); a run that reports tokens of a
model without a price stops its component with exit 4 and names the model. `--allow-unpriced` runs them
uncounted.

## Design input

```bash
node scripts/run-component.mjs Switch --request "..." --ref design/switch.png --ref design/switch-dark.png
node scripts/run-component.mjs Tabs --request "..." --figma "https://www.figma.com/design/<key>/UI?node-id=12-34"
```

References go to `specs/<name>/refs/` and are committed with the spec. For a Figma frame,
`scripts/figma-ref.mjs` saves its picture, its node data and a short summary (sizes, auto layout,
spacing, radii, colours, type, variants) with a personal access token (`FIGMA_TOKEN`, scope
`file_content:read`). Use a Dev or Full seat: a View seat gets about 20 such calls a month. For
interactive work, Figma's MCP server gives the same data: `claude mcp add --transport http figma
https://mcp.figma.com/mcp`, or `codex mcp add figma --url https://mcp.figma.com/mcp`.

The architect turns the references into a "Visual reference" section of the spec (measures as custom
properties); a picture that needs a part or state the pattern lacks is a `[CRITICAL]` question. In the
review step `visual-reviewer` compares screenshots of the fixture (`node scripts/screenshot.mjs <name>`)
with the references and reports differences; a person decides what to match. Why:
`docs/decisions/0013-design-references.md`.

## On GitHub

The repository's Agents tab (github.com/<owner>/<repo>/agents) lists the agent sessions, each with its
pull request. Three files put this workflow there:

- `.github/agents/*.agent.md`: the eight subagents as GitHub custom agents, generated from
  `.claude/agents/` by `npm run sync-rules`, and `component-builder`, the orchestrator that runs the
  ten steps on the pull request branch (`workflow.mjs start --here`).
- `.github/ISSUE_TEMPLATE/new-component.yml`: an issue form (name, purpose, pictures and Figma links,
  where to stop). Assign the issue to Copilot and pick component-builder: the session shows in the
  Agents tab, the work in its pull request, a commit per unit of work. It stops at approve on a
  `[CRITICAL]` question and asks in the pull request; answer there and mention it to go on.
- `.github/workflows/copilot-setup-steps.yml`: Node and Chromium for the live tests.

This needs a Copilot plan with the cloud agent (Pro and up); Claude and Codex as GitHub agents need
Pro+ or Enterprise. For Figma frames, add `FIGMA_TOKEN` under Settings > Secrets and variables > Agents, and allow
`api.figma.com` (and `www.w3.org` for the APG pages) under Settings > Copilot > Internet access. The hooks of this
repository do not run there, so step budgets are guidance and `npm run gates` before finishing is the
check. Why: `docs/decisions/0014-github-agents.md`.

## Other agents

Every agent reads `AGENTS.md`: commands, layers, invariants, the workflow and how to drive its steps by
hand (`workflow.mjs start`, `begin`, `checkpoint`, `done`, `note`, `block`), and "Before you finish".

| Agent | What it loads from this repository | What it does not get |
| --- | --- | --- |
| Cursor | `AGENTS.md`, `.cursor/rules/*.mdc` (generated path rules), `.claude/skills/` (so `/new-component` works), `.claude/agents/` (reviewers are `readonly`), and the hooks in `.claude/settings.json` | deny reasons from the hooks reach the person, not the agent; no step budget hook beyond what Cursor maps |
| GitHub Copilot | `AGENTS.md`, `.github/instructions/*.instructions.md` (generated path rules), `.claude/skills/`, `.github/agents/` (custom agents, see "On GitHub"); the cloud agent starts from `.github/workflows/copilot-setup-steps.yml` with Chromium installed | hooks |
| Codex | `AGENTS.md` (its table lists the path rules to read), `.codex/rules/` | skills in `.claude/skills/` (it reads `.agents/skills`; `ln -s ../.claude/skills .agents/skills` adds them), hooks |
| Gemini CLI | `AGENTS.md`, through `.gemini/settings.json` | skills (it reads `.agents/skills` too), hooks |
| Kiro | `AGENTS.md`, `.kiro/agents/ui-runner.json` | steering files, hooks |

Without hooks, the guards still run where it matters: `npm run check` and CI hold the static gates, and
`workflow.mjs done` holds every exit check. The step runner drives each of them unattended (see "Any
agent, any model").

## Layout

```
AGENTS.md                 shared instructions for every agent: commands, layers, invariants, workflow, style
CLAUDE.md                 @AGENTS.md plus only what is specific to Claude Code
.claude/
  rules/*.md              path rules (the single source): frontmatter description + paths
  agents/*.md             8 subagents: architect, test-writer, implementer, 5 reviewers
  skills/*/SKILL.md       new-component, resume-component, component-step (+ protocol.md, steps/*.md),
                          add-part, live-test, perf-check, release-check, adr
  commands/*.md           review-change, gates, catchup
  hooks/*.mjs             edit guards, post-edit checks, step budget, WIP commits, Stop gate, session context
  settings.json           permissions (allow / ask / deny) and hook wiring
.cursor/rules/*.mdc       generated from .claude/rules (Cursor); never edited by hand
.github/instructions/     generated from .claude/rules (Copilot); never edited by hand
.github/agents/           custom agents for GitHub: generated from .claude/agents, plus component-builder
.github/ISSUE_TEMPLATE/   the "New component" issue form for the agent on GitHub
.gemini/settings.json     points Gemini CLI at AGENTS.md
.codex/, .cursor/cli.json, .kiro/   what Codex, Cursor and Kiro may not run (push, publish, the runners)
agents.config.json        profiles: which agent and model run each step; prices for the spend cap
agents.env.example        the key variables; copy to ~/.config/ui-agents/env, outside the repository
.gitattributes            merge drivers for the files every component adds to
src/                      core, button, overlay, list, virtual, select
styles/                   index.css (layer order), tokens.css, components/*.css
tests/                    live tests, fixtures, conformance, a11y (ARIA tree, axe), render counter,
                          hook and workflow tests
specs/                    component specs; _template.md and the reference select.md; <name>/refs/ design input
docs/decisions/           decisions with numbers: why the rules are what they are
budgets.json              size and render budgets
scripts/                  build, gates, scaffold, rule sync, init; workflow.mjs (steps),
                          run-component.mjs (runner), run-batch.mjs (many at once), test-service.mjs,
                          agent-smoke.mjs, agent-keys.mjs, figma-ref.mjs, screenshot.mjs,
                          mutation-probe.mjs, flaky.mjs
  lib/agents/             one adapter per agent CLI, and the generic one
.workflow/                progress of a component: only on its feat/<name> branch, removed by the squash
bench/run.mjs             timing benches, two runs, medians
```

## Gates

| Command | What it checks | Time |
| --- | --- | --- |
| `npm run check` | types, import direction between layers, CSS (layers, prefix, logical properties, no `!important`), entry completeness (export, budget, spec, test), Cursor and Copilot rules and GitHub agents in sync, commands the skills run up front allowed, agent profiles and deny lists valid, no keys in tracked files | ~2 s |
| `npm test` | 48 live tests in Chromium (keyboard, pointer, focus, ARIA tree and axe per state, part conformance, controlled mode, RTL, SSR without hydration warnings, render budgets); 54 tests of the agent layer: hooks, workflow, agent adapters and runner against a stand-in CLI, token and cost accounting, keys, batches and merge queue, Figma input, the test service; two files at a time; console errors fail the test | ~43 s |
| `npm run size` | gzip size of every entry against `budgets.json` | ~1 s |
| `npm run gates` | all of the above, as in CI | ~45 s |
| `npm run bench` | action timings, reported, not gated | ~15 s |
| `node scripts/mutation-probe.mjs <name>` | breaks the component's source one edit at a time and checks that a test notices; a surviving mutant is behaviour no test checks. Verify step, not CI | 4–12 min |
| `node scripts/flaky.mjs <files> --runs 5` | pass rate of every test over N runs; no retries | N × file time |

## Claude Code hooks

| Event | Script | What it does |
| --- | --- | --- |
| PreToolUse Edit/Write | `guard-edits.mjs` | denies edits to generated files; checks a CSS file whole, as it will be after the edit (physical properties, rules outside a layer); asks a person when a budget number goes above the last commit's |
| PreToolUse Bash | `guard-bash.mjs` | denies skipping git hooks (`--no-verify`, `-n`, `core.hooksPath`) and writing guarded files through the shell; commit messages and heredocs are not read as commands. A hint, not a sandbox |
| PostToolUse Edit/Write | `after-edit.mjs` | checks layers and CSS for the changed file; after a rule edit regenerates the Cursor rules |
| PostToolUse, PostToolUseFailure (all) | `step-budget.mjs` | counts tool calls on the current step, failed ones and subagents included; at 80% of the budget asks to finish the unit and end, at 100% asks to stop |
| Stop | `stop-gate.mjs` | with uncommitted changes, does not let the turn end while `npm run check` is red; never blocks twice in a row; on a workflow branch commits the turn as WIP first, red or not |
| SubagentStop, PreCompact, SessionEnd | `checkpoint.mjs` | on a workflow branch commits everything changed as WIP; never blocks |
| SessionStart | `session-context.mjs` | branch, uncommitted files, specs awaiting approval, whether a test browser exists, the workflow step and its last notes |

Both PreToolUse hooks fail closed: if a hook crashes (broken input, an unreadable file, a broken module
it imports), the action is denied with a reason instead of passing silently, and `"onFailure": "block"`
covers a timeout. `settings.json` also turns fork mode off (`CLAUDE_CODE_FORK_SUBAGENT=0`), so a step
waits for its subagents instead of ending its turn while they still write. During the implement step `guard-edits` refuses changes to the
component's test file and fixture: on that step they are the oracle.

## Changing the rules

Edit `.claude/rules/<topic>.md`: Claude Code reads only `paths` from the frontmatter, and `description` is
for Cursor. The hook regenerates `.cursor/rules/`, `.github/instructions/` and the table in `AGENTS.md`;
outside Claude Code run `npm run sync-rules`. Raising a budget or changing an invariant goes through `/adr` and a record in
`docs/decisions/`.

## Evidence

The `research` branch holds the evidence behind the decisions: the research report on testing headless
components and on budgeted agent workflows (a short version and the full one), the mutation probe
results, and four end-to-end runs of the component workflow in clean clones (patches, runner logs,
progress files). The `feat/switch` branch is the commit the fourth run produced, as an example of the
output.
